#!/bin/bash

# Install the required packages
sudo dnf install -y mariadb1011-client-utils mariadb1011-server git

# Enable and start the MariaDB service
sudo systemctl enable --now mariadb

# Download the project
git clone https://github.com/shekeriev/bgapp

# Install the database required for the web application
sudo mysql -u root < ~/bgapp/db/db_setup.sql
