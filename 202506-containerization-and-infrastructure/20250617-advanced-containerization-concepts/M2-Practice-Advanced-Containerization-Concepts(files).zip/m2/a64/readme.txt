Will be added upon request.

It is essentially the same as the one for x64 (Intel64/AMD64).